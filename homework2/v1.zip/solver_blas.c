/*
 * Tema 2 ASC
 * 2023 Spring
 */
#include "utils.h"

/* 
 * Add your BLAS implementation here
 */
double* my_solver(int N, double *A, double *B) {
	printf("BLAS SOLVER\n");
	return NULL;
}
