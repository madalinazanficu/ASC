#ifndef HELPERS_H_
#define HELPERS_H_

void free_matrix(double **matrix);
void print_matrix(double *matrix, int N);

#endif  // HELPERS_H_